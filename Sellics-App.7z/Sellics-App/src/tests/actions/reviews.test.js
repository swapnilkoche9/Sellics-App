import * as configureMockStore from 'redux-mock-store'
import thunk from 'redux-thunk'

import {
  getReviewsSuccess,
  getReviewsFailure
} from '../../actions/reviews'

import * as types from '../../constants'
const middlewares = [thunk]
const mockStore = configureMockStore.default(middlewares)


test('should successfully get reviews', () => {
  const action = getReviewsSuccess(['review'])
  expect(action.type).toEqual('FETCH_ALL_REVIEWS_SUCCEEDED')
  expect(action.payload).toEqual(['review'])
})


test('should return an error for unsuccessful request', () => {
  const action = getReviewsFailure({
    error: 'error'
  })
  expect(action.type).toEqual('FETCH_ALL_REVIEWS_FAILED')
  expect(action.payload.error.error).toEqual('error')
})

