import React from 'react'
import Enzyme from 'enzyme'
import Adapter from 'enzyme-adapter-react-16'
import AvailableReviews from '../../components/AvailableReviews'
import chai, { expect as expects } from 'chai';
import chaiEnzyme from 'chai-enzyme';
import { shallow} from 'enzyme';
import sinon from 'sinon';
chai.use(chaiEnzyme());
Enzyme.configure({ adapter: new Adapter() })


const getPageParams = jest.fn()
const wrapper = shallow(
  <AvailableReviews
    review={['review']}
  />
)
test('should render AvailableReviews correctly', () => {
  expect(wrapper).toMatchSnapshot()
})

test('should render AvailableReviews with alt data correctly', () => {
  wrapper.setProps({
    review: ['rev1','rev2']
  })
  expect(wrapper).toMatchSnapshot()
})
