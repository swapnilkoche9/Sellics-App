import React from 'react'
import Enzyme from 'enzyme'
import Adapter from 'enzyme-adapter-react-16'
import Loading from '../../components/Loading'
import chai, { expect as expects } from 'chai';
import chaiEnzyme from 'chai-enzyme';
import { shallow } from 'enzyme';
import sinon from 'sinon';
chai.use(chaiEnzyme());
Enzyme.configure({ adapter: new Adapter() })


const refreshResults = jest.fn()
const wrapper = shallow(
    <Loading />
)
test('should render Loading correctly', () => {
    expect(wrapper).toMatchSnapshot()
})

it('should render  timeline-item', () => {
    expect(wrapper.find('.timeline-item').length).toBeGreaterThan(0);
});
it('should render header-top', () => {
    expect(wrapper.find('.header-top').length).toBeGreaterThan(0);
});
it('should render  header-left', () => {
    expect(wrapper.find('.header-left').length).toBeGreaterThan(0);
});
it('should render  header-right', () => {
    expect(wrapper.find('.header-right').length).toBeGreaterThan(0);
});

it('should render  header-bottom', () => {
    expect(wrapper.find('.header-bottom').length).toBeGreaterThan(0);
});
it('should render subheader-left', () => {
    expect(wrapper.find('.subheader-left').length).toBeGreaterThan(0);
});
it('should render  subheader-right', () => {
    expect(wrapper.find('.subheader-right').length).toBeGreaterThan(0);
});
it('should render  subheader-bottom', () => {
    expect(wrapper.find('.subheader-bottom').length).toBeGreaterThan(0);
});

it('should render  content-top', () => {
    expect(wrapper.find('.content-top').length).toBeGreaterThan(0);
});
it('should render content-first-end', () => {
    expect(wrapper.find('.content-first-end').length).toBeGreaterThan(0);
});
it('should render  content-second-line', () => {
    expect(wrapper.find('.content-second-line').length).toBeGreaterThan(0);
});
it('should render  content-second-end', () => {
    expect(wrapper.find('.content-second-end').length).toBeGreaterThan(0);
});
