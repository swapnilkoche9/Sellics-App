import React from 'react'
import Enzyme from 'enzyme'
import Adapter from 'enzyme-adapter-react-16'
import Rating from '../../components/Rating'
import chai, { expect as expects } from 'chai';
import chaiEnzyme from 'chai-enzyme';
import { shallow } from 'enzyme';
import sinon from 'sinon';
chai.use(chaiEnzyme());
Enzyme.configure({ adapter: new Adapter() })


const refreshResults = jest.fn()
const wrapper = shallow(
    <Rating
        rating={3}
    />
)
test('should render AvailableReviewsArea correctly', () => {
    expect(wrapper).toMatchSnapshot()
})

test('should render AvailableReviewsArea with alt data correctly', () => {
    wrapper.setProps({
        rating: 4
    })
    expect(wrapper).toMatchSnapshot()
})

it('should render  is-selected', () => {
    expect(wrapper.find('.is-selected').length).toBeGreaterThan(0);
});
it('should render  star-rating', () => {
    expect(wrapper.find('.star-rating').length).toBeGreaterThan(0);
});
it('should render  star-rating__star', () => {
    expect(wrapper.find('.star-rating__star').length).toBeGreaterThan(0);
});
