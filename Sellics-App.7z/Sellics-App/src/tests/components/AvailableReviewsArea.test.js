import React from 'react'
import Enzyme from 'enzyme'
import Adapter from 'enzyme-adapter-react-16'
import AvailableReviewsArea from '../../components/AvailableReviewsArea'
import chai, { expect as expects } from 'chai';
import chaiEnzyme from 'chai-enzyme';
import { shallow} from 'enzyme';
import sinon from 'sinon';
chai.use(chaiEnzyme());
Enzyme.configure({ adapter: new Adapter() })


const refreshResults = jest.fn()
const wrapper = shallow(
  <AvailableReviewsArea
    reviews={['review']}
    groupValue=''
    getSearchValue="search"
    refreshResults={refreshResults}
  />
)
test('should render AvailableReviewsArea correctly', () => {
  expect(wrapper).toMatchSnapshot()
})

test('should render AvailableReviewsArea with alt data correctly', () => {
  wrapper.setProps({
    reviews: ['rev1','rev2'],
    groupValue:'',
    getSearchValue:'search'
  })
  expect(wrapper).toMatchSnapshot()
})

it('should render  textField', () => {
  expect(wrapper.find('.textField').length).toBeGreaterThan(0);

  
});

