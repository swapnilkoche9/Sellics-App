import reviews from '../../reducers/reviews'

test('should setup default reviews values', () => {
  const state = reviews(undefined, { type: '@@INIT' })
  expect(state).toEqual({
    reviews: [],
    hasMoreReviews: true,
    error: ''
  })
})



test('should request to fetch all reviews', () => {
  const state = reviews(undefined, { type: 'FETCH_ALL_REVIEWS_REQUESTED' })
  expect(state.hasMoreReviews).toBe(true)
})

test('should successfully fetch all reviews', () => {
  const state = reviews(undefined, {
    type: 'FETCH_ALL_REVIEWS_SUCCEEDED',
    payload: { reviews: ['reviews'] }
  })
  expect(state.reviews).toEqual(['reviews'])
})

test('should return error on failure to fetch revies', () => {
  const state = reviews(undefined, {
    type: 'FETCH_ALL_REVIEWS_FAILED',
    payload: {
      error: {
        message: 'error'
      }
    }
  })
  expect(state.error).toEqual('error')
})

