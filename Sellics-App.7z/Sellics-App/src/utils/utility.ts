import moment from 'moment';

export const sortByOrderValue = (reviews: any, orderValue: string, groupValue: string) => {
    let sortedReviews = reviews
    if (groupValue === '') {
        if (orderValue === 'latest') {
            sortedReviews = reviews && reviews.sort((review1: any, review2: any) => {
                let review1Date = new Date(review1.reviewCreated)
                let review2Date = new Date(review2.reviewCreated)
                if (review1Date > review2Date) return -1;
                if (review1Date < review2Date) return 1;
                return 0;
            })
        } else if (orderValue === 'oldest') {
            sortedReviews = reviews.sort((review1: any, review2: any) => {
                let review1Date = new Date(review1.reviewCreated)
                let review2Date = new Date(review2.reviewCreated)
                if (review1Date > review2Date) return 1;
                if (review1Date < review2Date) return -1;
                return 0;
            })
        } else {
            sortedReviews = reviews
        }

    } else if (groupValue === 'week') {

        if (orderValue === 'latest') {
            sortedReviews = reviews && reviews.sort((review1: any, review2: any) => {
                return parseInt(review1[0].split('-')[0]) - parseInt(review2[0].split('-')[0])
            })
        } else if (orderValue === 'oldest') {
            sortedReviews = reviews.sort((review1: any, review2: any) => {
                return parseInt(review2[0].split('-')[0]) - parseInt(review1[0].split('-')[0])
            })
        } else {
            sortedReviews = reviews
        }

    } else {
        if (orderValue === 'latest') {
            sortedReviews = reviews && reviews.sort((review1: any, review2: any) => {
                return review2[0] - review1[0]
            })
        } else if (orderValue === 'oldest') {
            sortedReviews = reviews.sort((review1: any, review2: any) => {
                return review1[0] - review2[0]
            })
        } else {
            sortedReviews = reviews
        }
    }
    return sortedReviews

}

export const filterByFilterValue = (reviews: any, filterValue: Array<object>, groupValue: string, orderValue: string, searchValue: string) => {

    let filteredReviews = reviews
    const filterValues: any = []
    if (groupValue === '') {
        if (filterValue === null || filterValue.length === 0) {
            filteredReviews = orderValue !== "" ? sortByOrderValue(filteredReviews, orderValue, groupValue) : filteredReviews
            filteredReviews = searchValue !== "" ? filterBySearchValue(filteredReviews, searchValue, groupValue, orderValue, filterValue) : filteredReviews

        } else {
            filteredReviews = orderValue !== "" ? sortByOrderValue(filteredReviews, orderValue, groupValue) : filteredReviews
            filteredReviews = searchValue !== "" ? filterBySearchValue(filteredReviews, searchValue, groupValue, orderValue, filterValue) : filteredReviews
            filterValue.forEach((value: any, index: number) => {
                filterValues[index] = value['value']
            })
            filteredReviews = filteredReviews && filteredReviews.filter((review: any) => filterValues.includes(review.stars.toString()))
        }
        return filteredReviews
    }
    else {
        return groupByGroupValue(filteredReviews, groupValue, orderValue, filterValue, searchValue)
    }
}


export const filterBySearchValue = (reviews: any, searchValue: string, groupValue: string, orderValue: string, filterValue: any) => {

    let filteredReviews: any = reviews
    if (groupValue === '') {
        if (searchValue === '') {
            filteredReviews = orderValue !== "" ? sortByOrderValue(filteredReviews, orderValue, groupValue) : filteredReviews
            filteredReviews = filterValue && filterValue.length > 0 ? filterByFilterValue(filteredReviews, filterValue, groupValue, orderValue, searchValue) : filteredReviews
        }
        else {
            filteredReviews = filteredReviews && filteredReviews.filter((review: any) => {
                return (review.title && review.title.toString().toLowerCase().includes(searchValue && searchValue.toLowerCase()) || review.content && review.content.toString().toLowerCase().includes(searchValue && searchValue.toLowerCase()))
            })
        }

    } else {
        return groupByGroupValue(filteredReviews, groupValue, orderValue, filterValue, searchValue)
    }
    return filteredReviews

}

export const groupByGroupValue = (reviews: any, groupValue: string, orderValue: string, filterValue: any, searchValue: string) => {
    let groupedReviews = reviews
    let reviewsData = new Map()
    let reviewsArray: any
    let sortedReviews: any
    groupedReviews = filterByFilterValue(groupedReviews, filterValue, '', orderValue, searchValue)
    groupedReviews = filterBySearchValue(groupedReviews, searchValue, '', orderValue, filterValue)
    groupedReviews = sortByOrderValue(groupedReviews, orderValue, '')

    groupedReviews.forEach((review: any) => {
        const month = new Date(review.reviewCreated).getMonth() + 1
        if (reviewsData.has(month)) {
            const eachReview = reviewsData.get(month)
            if (Array.isArray(eachReview))
                reviewsArray = eachReview.concat(review)
            else
                reviewsArray = [eachReview]
            reviewsData.set(month, reviewsArray)
        } else {
            reviewsData.set(month, [review])
        }

    });
    sortedReviews = [...reviewsData.entries()].sort((a, b) => {
        return a[0] - b[0]
    })

    if (groupValue === 'month') {
        sortedReviews = sortByOrderValue(sortedReviews, orderValue, groupValue)
        return sortedReviews
    }
    else if (groupValue === 'week') {
        let groupByWeekData = new Map()
        sortedReviews.reduce((acc: any, review: any) => {
            reviewsData.get(review[0]).forEach((review: any) => {
                let yearWeek = moment(review.reviewCreated).week() + '-' + moment(review.reviewCreated).year()

                if (groupByWeekData.has(yearWeek)) {
                    const eachReview = groupByWeekData.get(yearWeek)
                    if (Array.isArray(eachReview)) {
                        reviewsArray = eachReview.concat(review)
                    }
                    else {
                        reviewsArray = [review]
                    }
                    groupByWeekData.set(yearWeek, reviewsArray)
                } else {
                    groupByWeekData.set(yearWeek, [review])
                }
            })
        }, [])

        sortedReviews = [...groupByWeekData.entries()]
        sortedReviews = sortByOrderValue(sortedReviews, orderValue, groupValue)
        return sortedReviews

    } else if (groupValue === 'day') {
        let groupByDayData = new Map()
        sortedReviews.forEach((review: any) => {
            reviewsData.get(review[0]).forEach((review: any) => {
                let date = review.reviewCreated
                if (groupByDayData.has(date)) {
                    const eachReview = groupByDayData.get(date)
                    if (Array.isArray(eachReview))
                        reviewsArray = eachReview.concat(review)
                    else
                        reviewsArray = [eachReview]
                    groupByDayData.set(date, reviewsArray)
                } else {
                    groupByDayData.set(date, [review])
                }
            })
        })
        sortedReviews = [...groupByDayData.entries()]
        sortedReviews = sortByOrderValue(sortedReviews, orderValue, groupValue)
        return sortedReviews
    } else {
        return groupedReviews
    }
}


export const getMonthName = (month: number) => {
    const months = ["January", "February", "March", "April", "May", "June", "July",
        "August", "September", "October", "November", "December"];
    return months[month]

}
declare global {
    interface Date {
        getWeek(): any
    }
}
Date.prototype.getWeek = function () {
    let date = new Date(this.getTime());
    date.setHours(0, 0, 0, 0);
    date.setDate(date.getDate() + 3 - (date.getDay() + 6) % 7);
    let week1 = new Date(date.getFullYear(), 0, 4);
    return 1 + Math.round(((date.getTime() - week1.getTime()) / 86400000 - 3 + (week1.getDay() + 6) % 7) / 7);
}

export const getWeekRange = (weekOfYear: any) => {
    const weekNo = weekOfYear.split('-')[0]
    const y = weekOfYear.split('-')[1]
    let d1, numOfdaysPastSinceLastMonday, rangeIsFrom, rangeIsTo;
    d1 = new Date('' + y + '');
    numOfdaysPastSinceLastMonday = d1.getDay() - 1;
    d1.setDate(d1.getDate() - numOfdaysPastSinceLastMonday);
    d1.setDate(d1.getDate() + (7 * (weekNo - d1.getWeek())));
    rangeIsFrom = d1.getDate() + "-" + (d1.getMonth() + 1) + "-" + d1.getFullYear();
    d1.setDate(d1.getDate() + 6);
    rangeIsTo = d1.getDate() + "-" + (d1.getMonth() + 1) + "-" + d1.getFullYear();
    return rangeIsFrom + " to " + rangeIsTo;

}