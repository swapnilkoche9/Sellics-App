export type AvailableReviewsProps = {
    review: review
}

export type AvailableReviewsAreaProps = {
    reviews: Array<review>
    groupValue: any
    getSearchValue:any
    refreshResults:any
}

export type ButtonProps = {
    text: string,
    handleClick: any
}

export type DropDownData = {
    isMulti: boolean
    dropdownContent: Array<object>
    defaultDropdownValue: object
    dropDownLabel: string
    placeholder: string
    dropDownIndex: number
}

export type DropDownProps = {
    dropDownData: DropDownData
}

export type RatingProps={
    rating:any
}

export type GenericAction = {
    type: string,
    payload: any
}

export type review = {

    country: string,
    reviewId: string,
    childAsin: string,
    authorId: any,
    title: string,
    content: string,
    stars: number,
    verified: boolean,
    reviewCreated: number,
    productImg: string,
    productTitle: string,
    watched: boolean,
    created: number,
    map:Function

}















