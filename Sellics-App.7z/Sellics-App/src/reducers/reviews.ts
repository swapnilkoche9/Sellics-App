import {
  FETCH_ALL_REVIEWS_SUCCEEDED,
  FETCH_ALL_REVIEWS_FAILED
} from '../constants'

import { GenericAction } from '../utils/interface'
const initialState = {
  reviews: [],
  hasMoreReviews: true,
  error: ''
}


function reviews(state = initialState, action: GenericAction) {
  switch (action.type) {
    case FETCH_ALL_REVIEWS_SUCCEEDED:

      return {
        ...state,
        reviews: state.reviews && state.reviews.concat(action.payload.reviews),
        hasMoreReviews: action.payload.hasMore
      }

    case FETCH_ALL_REVIEWS_FAILED:
      return {
        ...state,
        reviews: {
          ...state.reviews
        },
        hasMoreReviews: false,
        error: action.payload.error.message

      }

    default:
      return state
  }
}

export default reviews