import { combineReducers } from 'redux'
import reviews from './reviews'

const Reducers = combineReducers({
  reviews
})

export default Reducers
