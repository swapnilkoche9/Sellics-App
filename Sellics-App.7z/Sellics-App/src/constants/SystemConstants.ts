const systemConstants = {
    PRODUCT_TITLE:'Product Title:',
    DATE:'Date:',
    STARS:'Stars:',
    SEARCH_FOR_REVIEWS:'Search For Review',
    url :"https://cors-anywhere.herokuapp.com/https://sellics-frontend-test.herokuapp.com/reviews/",
    PURCHASE: 'Purchase',
    MY_ORDERS: 'My Orders',
    SELL: 'Sell',
    SELLICS_TEXT: 'sellics',
    BUTTON_TEXT: 'Filter',
    ORANGE_COLOR: '#EA7F28',
    DARK_GRAY_COLOR: '#4A4A4A',
    LIGHT_GRAY_COLOR: '#EDEDED',
    SKY_BLUE_COLOR: '#4dd2ff',
    WHITE_COLOR: 'white',
    FOOTER_TEXT: '© Sellics Group',
   
};
export default systemConstants;
