import {
  FETCH_ALL_REVIEWS_SUCCEEDED,
  FETCH_ALL_REVIEWS_FAILED
} from '../constants'
import { review } from '../utils/interface'

export const getReviewsSuccess = (data: Array<review>) => {
  return {
    type: FETCH_ALL_REVIEWS_SUCCEEDED,
    payload: data
  }
}

export const getReviewsFailure = (error: string) => {
  return {
    type: FETCH_ALL_REVIEWS_FAILED,
    payload: {
      error: error
    }
  }
}
