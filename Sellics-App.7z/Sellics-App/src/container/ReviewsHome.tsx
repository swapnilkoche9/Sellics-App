import React, { useState, useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import * as reviewsActions from '../actions/reviews'
import * as utility from '../utils/utility'
import { Suspense, lazy } from 'react';
import axios from 'axios'
import constants from '../constants/SystemConstants'
import styled from 'styled-components';

const ReviewListContainer = styled.div`
 display: flex;
 flex-direction: row;
 @media only screen and (max-width: 600px) {
  {
    flex-direction: column;
  }
`;
const AvailableReviewsArea = lazy(() => import('../components/AvailableReviewsArea'));
const ReviewsFiltersArea = lazy(() => import('../components/ReviewsFiltersArea'));
const Loading = lazy(() => import('../components/Loading'));
export const DropDownValueContext = React.createContext([({ }) => { }]);

const ReviewsHome = () => {
  const [IsFetching, setIsFetching] = useState(true)
  const [PageNumber, setPageNumber] = useState(1)
  const [Reviews, setReviews] = useState(useSelector((state: any) => state.reviews.reviews))
  const [FilteredReviews, setFilteredReviews] = useState([])
  const [GroupValue, setGroupValue] = useState('')
  const [OrderValue, setOrderValue] = useState('')
  const [FilterValue, setFilterValue] = useState([{ label: "5", value: "5" }])
  const [SearchValue, setSearchValue] = useState('')
  const [HasMore, setHasMore] = useState(true)
  const [IsLoading, setIsLoading] = useState(true)
  const dispatch = useDispatch()

  const useFetch = async () => {

    await axios.get(constants.url + PageNumber)
      .then(response => {
        setIsFetching(false)
        setIsLoading(false)
        setHasMore(response.data.hasMore)
        dispatch(reviewsActions.getReviewsSuccess(response.data))
        setReviews(Reviews.concat(response.data.reviews));
        setFilteredReviews(utility.filterByFilterValue(Reviews.concat(response.data.reviews), FilterValue, GroupValue, OrderValue, SearchValue))
        setPageNumber(PageNumber + 1)

      })
      .catch((error) => {
        dispatch(reviewsActions.getReviewsFailure(error))
      })

  }
  function handleScroll() {
    if ((window.innerHeight + document.documentElement.scrollTop !== document.documentElement.offsetHeight || !IsFetching) && HasMore) {
      setIsFetching(true);
    }

  }
  useEffect(() => {
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (IsFetching && HasMore) {
      setIsLoading(true)
      useFetch()
    }

  }, [IsFetching]);

  // function to get filtered criterion 
  const getGroupByDropDownValue = (value: any) => {
    value ? setGroupValue(value['value']) : setGroupValue('')
    const reviews = utility.groupByGroupValue(Reviews, value ? value['value'] : null, OrderValue, FilterValue, SearchValue)
    setFilteredReviews(reviews)
  }

  const getOrderByDropDownValue = (value: any) => {
    value ? setOrderValue(value['value']) : setOrderValue('')
    const reviews = utility.sortByOrderValue(FilteredReviews.length > 0 ? FilteredReviews : Reviews, value ? value['value'] : null, GroupValue, FilterValue, SearchValue)
    setFilteredReviews(reviews)
  }

  const getFilterByDropDownValue = (value: any) => {
    setFilterValue(value)
    const reviews = utility.filterByFilterValue(Reviews, value, GroupValue, OrderValue, SearchValue)
    setFilteredReviews(reviews)

  }
  const getSearchValue = (changeEvent: any) => {
    setSearchValue(changeEvent.target.value)
    const reviews = utility.filterBySearchValue(Reviews, changeEvent.target.value, GroupValue, OrderValue, FilterValue)
    setFilteredReviews(reviews)
  }
  const refreshResults = () => {
    const reviews = utility.filterByFilterValue(FilteredReviews.length > 0 ? FilteredReviews : Reviews, FilterValue, GroupValue, OrderValue, SearchValue)
    setFilteredReviews(reviews)
  }
  return (
    <ReviewListContainer>
      <Suspense fallback={<div />}>
        <DropDownValueContext.Provider value={[getGroupByDropDownValue, getOrderByDropDownValue, getFilterByDropDownValue]}>
          <ReviewsFiltersArea />
        </DropDownValueContext.Provider>
        {!IsLoading && Reviews && Reviews.length > 0 ?
          <Suspense fallback={<Loading />}>
            <AvailableReviewsArea reviews={FilteredReviews} getSearchValue={getSearchValue} groupValue={GroupValue} refreshResults={refreshResults} />
          </Suspense>
          :
          <Suspense fallback={<div />}><Loading /></Suspense>}
      </Suspense>
    </ReviewListContainer>
  )
}

export default ReviewsHome











