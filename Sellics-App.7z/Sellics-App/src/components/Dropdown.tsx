import React, { useContext } from 'react'
import Select from 'react-select';
import styled from 'styled-components';
import constants from '../constants/SystemConstants'
import { DropDownProps } from '../utils/interface'
import { DropDownValueContext } from '../container/ReviewsHome'


const DropDownContainer = styled.div`
display: flex;
flex-direction: column;
margin-top: 12px;
`;

const DropDown = styled.div`
font-size: 14px
`;

const DropDownLabel = styled.label`
margin-bottom: 12px;
text-align: left;
font-size: 14px;
color: ${constants.DARK_GRAY_COLOR}
`;

const dropDownStyles = {
  option: (styles: any, { isFocused }: any) => {
    return {
      ...styles,
      backgroundColor: isFocused ? constants.SKY_BLUE_COLOR : constants.WHITE_COLOR,
      color: isFocused ? constants.WHITE_COLOR : constants.DARK_GRAY_COLOR,
    };
  },
  placeholder: (styles: any) => {
    return {
      ...styles,
      color: constants.DARK_GRAY_COLOR,
    }
  }

};

const Dropdown = (props: DropDownProps) => {
  const getDropDownValue = useContext(DropDownValueContext)
  const {
    isMulti,
    dropdownContent,
    defaultDropdownValue,
    dropDownLabel,
    placeholder,
    dropDownIndex
  } = props.dropDownData


  return (
    <DropDownContainer>
      <DropDownLabel>{dropDownLabel}</DropDownLabel>
      <DropDown>
        <Select styles={dropDownStyles} key={dropDownIndex} options={dropdownContent} isMulti={isMulti} isSearchable={true} isClearable={true} onChange={getDropDownValue[dropDownIndex]} placeholder={placeholder} defaultValue={defaultDropdownValue} />
      </DropDown>
    </DropDownContainer>
  )
}

export default Dropdown
