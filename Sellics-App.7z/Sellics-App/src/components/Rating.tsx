import React from 'react'
import { RatingProps } from '../utils/interface'

const Rating = (props: RatingProps) => {
    let stars = [];
    for (let i = 0; i < 5; i++) {
        let _class = 'star-rating__star';
        if (props.rating > i && props.rating != null) {
            _class += ' is-selected';
        }
        stars.push(
            <label
                className={_class} key={i}>
                ★
            </label>
        );
    }
    return (
        <div className="star-rating">
            {stars}
        </div>
    );
}

export default Rating
