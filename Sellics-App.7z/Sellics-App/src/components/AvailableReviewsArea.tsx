import React from 'react'
import constants from '../constants/SystemConstants'
import { AvailableReviewsAreaProps, review } from '../utils/interface'
import TextField from '@material-ui/core/TextField';
import { Suspense, lazy } from 'react';
import styled from 'styled-components';
import * as utility from '../utils/utility'

const AvailableReviews = lazy(() => import('./AvailableReviews'));
const Button = lazy(() => import('./Button'));

const GroupedReviewsTitle = styled.div`
  text-align: start;
  color: ${constants.DARK_GRAY_COLOR};
  display: flex;
  flex-direction: row;
  margin-bottom: 12px;
  margin-top: 40px;
  font-size: 14px;
  font-weight: 500;
  color:#D37324
`;

const AvailableReviewsContainer = styled.div`
    width: 75%;
    padding: 8px;
    margin-right: 10px;
  @media only screen and (max-width: 600px) {
    {
      width: unset;
    }
`;

const NoReviewsPresent = styled.div`
font-size: 30px;
margin-top: 100px;
margin-left:100px;
`;
const RefreshButton = styled.div`
  margin-top:30px;
  float:right;
  margin-right:30px;
`;
const SearchAndButtonContainer = styled.div`
 margin-bottom:120px
`;
const SearchTextBox = styled.div`
 float:left
`;
const AvailableReviewsArea = (props: AvailableReviewsAreaProps) => {
  const {
    reviews,
    groupValue,
    getSearchValue,
    refreshResults
  } = props
  const renderAvailableReviews = (reviews: Array<review>) => {
    return reviews.length > 0 && reviews.map((review: review, index: number) => {
      return (
        <Suspense fallback={<div />} key={index}>
          <AvailableReviews
            review={review}
          />
        </Suspense>
      )
    })
  }
  const availavleGroupedReviews = (groupedReview: Array<review>) => {
    return groupedReview[1].map((review: any) => {
      return (
        <Suspense fallback={<div />} key={review.reviewId}>
          <AvailableReviews
            review={review}
          />
        </Suspense>
      )
    })
  }
  const renderGroupedReviews = (reviews: Array<review>) => {
    return reviews.length > 0 && reviews.map((groupedReview: any, index: number) => {
      return (
        <div key={index}>
          {groupValue === "day" ? <GroupedReviewsTitle>{new Date(groupedReview[0]).getDate() + ' ' + utility.getMonthName(new Date(groupedReview[0]).getMonth()) + ' ' + new Date(groupedReview[0]).getFullYear()}</GroupedReviewsTitle> :
            groupValue === "month" ? <GroupedReviewsTitle>{utility.getMonthName(groupedReview[0] - 1)}</GroupedReviewsTitle> :
              <GroupedReviewsTitle>{utility.getWeekRange(groupedReview[0])}</GroupedReviewsTitle>}
          {availavleGroupedReviews(groupedReview)}
        </div>

      )
    })
  }

  return (
    <AvailableReviewsContainer>
      <SearchAndButtonContainer>
        <SearchTextBox>
          <TextField
            type="text"
            id="searchFiels"
            className="textField"
            margin="normal"
            multiline={false}
            onChange={getSearchValue}
            autoFocus={false}
            label={constants.SEARCH_FOR_REVIEWS}
          />
          {reviews.length === 0 ? <NoReviewsPresent>No Result Found</NoReviewsPresent> : <div />}
        </SearchTextBox>
        <RefreshButton><Button handleClick={refreshResults} text="Refresh" /></RefreshButton>
      </SearchAndButtonContainer>
      {groupValue === '' ? renderAvailableReviews(reviews) : renderGroupedReviews(reviews)}
    </AvailableReviewsContainer>
  )
}

export default AvailableReviewsArea
