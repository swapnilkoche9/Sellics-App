import React from 'react'
import constants from '../constants/SystemConstants'
import styled from 'styled-components';

const FooterText = styled.div`
    margin-top:32px; 
    font-size: 14px;
`;
const FooterContainer = styled.footer`
    padding: 12px 0;
    width: 100%;
    text-align: center;
    border-top: 0.2rem solid ${constants.LIGHT_GRAY_COLOR};
    height: 80px;
`;

const Footer = () => (
  <FooterContainer>
    <FooterText>{constants.FOOTER_TEXT}</FooterText>
  </FooterContainer>
)

export default Footer
