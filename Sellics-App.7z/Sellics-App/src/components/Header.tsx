import React from 'react'
import logo from '../assets/logo.png'
import constants from '../constants/SystemConstants'
import styled from 'styled-components';

const HeaderContainer = styled.div`
    display: flex;
    flex-direction: column;
    justify-content: center;
    border-bottom: 0.2rem solid ${constants.LIGHT_GRAY_COLOR};
    margin-bottom: 12px;
    padding: 12px 0;
    height: 80px;
`;
const HeaderLeft = styled.div`
display: flex;
margin-left: 24px;
position: absolute;
width: 210px;
height: 45px;
`;

const HeaderLogo = styled.img`
width: 100%;
  height: auto;
`;


const Header = () => (
  <HeaderContainer>
    <HeaderLeft>
      <HeaderLogo src={logo} alt={constants.SELLICS_TEXT} />
    </HeaderLeft>
  </HeaderContainer>
)

export default Header
