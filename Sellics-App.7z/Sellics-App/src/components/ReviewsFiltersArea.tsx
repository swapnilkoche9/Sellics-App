import React from 'react'
import { Suspense, lazy } from 'react';
import constants from '../constants/SystemConstants'
import styled from 'styled-components';

const Dropdown = lazy(() => import('./Dropdown'));

const Rating = styled.span`
color:${constants.ORANGE_COLOR}
`;

const FiltersContainer = styled.div`
height: 250px;
width: 21%;
border: .2rem solid ${constants.LIGHT_GRAY_COLOR};
padding: 24px;
margin: 24px;
@media only screen and (max-width: 600px) {
  {
    width: auto;
  }
`;

const FiltersContainerContent = styled.div`
position: relative;
display: flex;
flex-direction: column;
text-align: start;
`;
const FilterDropdown = styled.div`
margin-bottom: 18px;
`;

const reviewsOperationsDropdown = [
  {
    dropDownIndex: 0,
    dropDownLabel: 'Group by',
    dropdownContent: [
      { label: 'day', value: 'day' },
      { label: 'week', value: 'week' },
      { label: 'month', value: 'month' }
    ],
    defaultDropdownValue: '',
    isMulti: false,
    placeholder: 'select'

  },
  {
    dropDownIndex: 1,
    dropDownLabel: 'Order by',
    dropdownContent: [
      { label: 'latest', value: 'latest' },
      { label: 'oldest', value: 'oldest' }
    ],
    defaultDropdownValue: '',
    isMulti: false,
    placeholder: 'select'

  },
  {
    dropDownIndex: 2,
    dropDownLabel: 'Filter by',
    dropdownContent: [
      { label: <div>1 <Rating className="fa fa-star checked" /></div>, value: '1' },
      { label: <div>2 <Rating className="fa fa-star checked" /></div>, value: '2' },
      { label: <div>3 <Rating className="fa fa-star checked" /></div>, value: '3' },
      { label: <div>4 <Rating className="fa fa-star checked" /></div>, value: '4' },
      { label: <div>5 <Rating className="fa fa-star checked" /></div>, value: '5' }
    ],
    defaultDropdownValue: { label: <div>5 <Rating className="fa fa-star checked" /></div>, value: '5' },
    isMulti: true,
    placeholder: 'select'

  }
]

const renderDropdown = () => {
  return reviewsOperationsDropdown.map((dropDownData: any, index: number) => {
    return (
      <Suspense key={index} fallback={<div />}>
        <Dropdown dropDownData={dropDownData} />
      </Suspense>
    )
  })

}

const ReviewsFiltersArea = () => {

  return (
    <FiltersContainer>
      <FiltersContainerContent>
        <FilterDropdown>
          {renderDropdown()}
        </FilterDropdown>
      </FiltersContainerContent>
    </FiltersContainer>
  )
}

export default ReviewsFiltersArea
