import React from 'react'
import Rating from './Rating'
import constants from '../constants/SystemConstants'
import { AvailableReviewsProps } from '../utils/interface'
import styled from 'styled-components';
import product from '../assets/product.png'

const AvailableReviewContent = styled.div`
  width: 100%;
  border: 0.2rem solid ${constants.LIGHT_GRAY_COLOR};
  margin-top: 14px;
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  @media only screen and (max-width: 600px) {
    {
      flex-direction: column;
    }
`;

const ProductImageConatiner = styled.div`
  margin: 14px;
  width: 20%; 
  background-color: ${constants.LIGHT_GRAY_COLOR};
  height: 100px;
`;
const ProductImage = styled.img`
height: 90px;
padding: 8px;
`;
const AvailableReviewDetails = styled.div`
display: flex;
flex-direction: column;
margin: 14px;
width: 50%;
`;
const AvailableReviewText = styled.div`
  text-align: start;
  margin: 0;
  color: ${constants.DARK_GRAY_COLOR};
  display: flex;
  flex-direction: row;
  margin-bottom: 12px;
  font-size: 14px;
`;

const ProductTitleLabel = styled.div`
margin-right: 10px;
`;

const ProductTitle = styled.div`
margin-right: 10px;
white-space: nowrap; 
width: 160px; 
overflow: hidden;
text-overflow: ellipsis; 
`;

const ReviewDetails = styled.div`
  display: flex;
  flex-direction: column;
  margin: 12px 12px 12px 25px;
  width: 100%;
  @media only screen and (max-width: 600px) {
    {
     width:unset
    }
`;

const ReviewTitle = styled.div`
  text-align: start;
  margin: 0;
  color: ${constants.DARK_GRAY_COLOR};
  display: flex;
  flex-direction: row;
  margin-bottom: 12px;
  font-size: 18px;
  font-weight: 700;
`;
const AvailableReviews = (props: AvailableReviewsProps) => {
  const review = props.review

  return (
    <AvailableReviewContent>
      <ProductImageConatiner>
        <ProductImage src={product} alt="product" />
      </ProductImageConatiner>
      <AvailableReviewDetails>
        <AvailableReviewText>
          <ProductTitleLabel >{constants.PRODUCT_TITLE}</ProductTitleLabel>
          <ProductTitle >{review.productTitle}</ProductTitle>
        </AvailableReviewText>
        <AvailableReviewText>
          <ProductTitleLabel >{constants.DATE}</ProductTitleLabel>
          <ProductTitleLabel>{("0" + new Date(review.reviewCreated).getDate()).slice(-2) + '.' + ("0" + (new Date(review.reviewCreated).getMonth() + 1)).slice(-2)
            + '.' + new Date(review.reviewCreated).getFullYear()}</ProductTitleLabel>
        </AvailableReviewText>
        <AvailableReviewText>
          <ProductTitleLabel >{constants.STARS}</ProductTitleLabel>
          <Rating rating={review.stars} />
        </AvailableReviewText>
      </AvailableReviewDetails>
      <ReviewDetails>
        <ReviewTitle>
          {review.title}
        </ReviewTitle>
        <AvailableReviewText>
          {review.content}
        </AvailableReviewText>
      </ReviewDetails>
    </AvailableReviewContent>
  )
}

export default AvailableReviews
